// Minimal PeerJS signaling server. Only brokers the connection; game traffic goes peer-to-peer.
const { PeerServer } = require('peer');
const port = Number(process.env.PORT) || 9000;
PeerServer({
  port,
  path: '/',
  proxied: true,            // behind Render/Railway/Fly/etc. HTTPS proxy
  allow_discovery: false,
  corsOptions: { origin: true }
}, () => console.log('PeerJS server listening on ' + port));
