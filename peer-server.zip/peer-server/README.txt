1. Put this folder in a GitHub repo (or upload it to Render / Railway / Fly.io / Glitch).
2. Build command: npm install     Start command: npm start
3. You get a URL like  my-peer.onrender.com
4. Open the game with:  https://YOUR-GAME-PAGE/#peerhost=my-peer.onrender.com
   (everyone who joins must use a link containing the same peerhost=...)
   Share link format:   https://YOUR-GAME-PAGE/#join=ABCDE&peerhost=my-peer.onrender.com
5. To go back to the default server: add  #peerhost=default
Free hosts sleep when idle, so the first connection can take ~30 seconds.
